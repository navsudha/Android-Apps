package com.example.calculatetakehometip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlin.math.absoluteValue

class MainActivity : AppCompatActivity() {
    private lateinit var Cash1: EditText
    private lateinit var Cash2: EditText
    private lateinit var Cash3: EditText
    private lateinit var Cash4: EditText
    private lateinit var Cash5: EditText
    private lateinit var Cash6: EditText
    private lateinit var Dfloat: EditText
    private lateinit var Ttip: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Cash1 = findViewById(R.id.Cash1)
        Cash2 = findViewById(R.id.Cash2)
        Cash3 = findViewById(R.id.Cash3)
        Cash4 = findViewById(R.id.Cash4)
        Cash5 = findViewById(R.id.Cash5)
        Cash6 = findViewById(R.id.Cash6)
        Dfloat = findViewById(R.id.Dfloat)
        Ttip = findViewById(R.id.Ttip)
        var cButton = findViewById<Button>(R.id.cButton)

        cButton?.setOnClickListener()
        {
            ComputeFinalTip()
        }

    }

    private fun ComputeFinalTip() {
        //Get all Values from the text boxes
        val cash1 = Cash1.text.toString().toDouble()
        val cash2 = Cash2.text.toString().toDouble()
        val cash3 = Cash3.text.toString().toDouble()
        val cash4 = Cash4.text.toString().toDouble()
        val cash5 = Cash5.text.toString().toDouble()
        val cash6 = Cash6.text.toString().toDouble()
        val dfloat = Dfloat.text.toString().toDouble()
        val ttip = Ttip.text.toString().toDouble()

        // calculation
        val ttlCash = cash1+cash2+cash3+cash4+cash5+cash6
        val flCash = ttlCash + dfloat
        var finalTip = flCash - ttip
        var Rtext = ""

        // giving back or needing extra

        if (finalTip < 0){
            Rtext = "Driver gets another $";
        }
        else{
            Rtext = "Please give back $"
        }

        // show on thE UI

        finalTip = finalTip.absoluteValue
        val finalText = Rtext + finalTip.toString()
        val toast = Toast.makeText(applicationContext, finalText, Toast.LENGTH_LONG)
        toast.show()

        //ResultView.text =  Rtext + finalTip.toString()
    }
}